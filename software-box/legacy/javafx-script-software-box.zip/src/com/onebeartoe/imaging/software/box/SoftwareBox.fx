
package com.onebeartoe.imaging.software.box;

import javafx.scene.CustomNode;
import javafx.scene.Node;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.input.MouseEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.effect.PerspectiveTransform;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Circle;

import javafx.scene.text.Text;

public class SoftwareBox extends CustomNode
{
    public var width = 180;

    public var height = 40;

    public var textXPercent = 0.3;

    public var color = Color.GREEN;

    var title : String = "onebeartoe.org - JavaFX Buttons";

    public var frontRightX = 186.6;

    public var frontLeftX = 13.4;

    public var frontUpperRightY = 10.0;

    public var frontUpperLeftY = 10.0;

    public var sideLeftX = -13.4;

    public var sideUpperLeftY = 10.0;   

    public var frontImage = Image
    {
        url: "{__DIR__}front.jpg";
    }

    public var sideImage = Image
    {
        url: "{__DIR__}side.jpg";
    }

    var a = Text
    {
        layoutX: bind sideLeftX, layoutY: bind sideUpperLeftY
        fill: Color.RED
        content: "A"
    }

    var b = Text
    {
        layoutX: bind frontLeftX, layoutY: bind frontUpperLeftY
        fill: Color.RED
        content: "B"
    }

    var c = Circle
    {
        centerX: bind frontRightX, centerY: bind frontUpperRightY
        radius: 3
        fill: Color.RED
    }

    var d = Text
    {
        layoutX: bind (c.centerX - (b.layoutX - a.layoutX) ),
        layoutY: bind (c.centerY - (b.layoutY -  a.layoutY) )

        fill: Color.RED
        content: "d"
    }

    public override var onMousePressed = function(event: MouseEvent)
    {
        scaleX = 0.8;
        scaleY = 0.8;
        println("pressed r");
    }

    public override var onMouseReleased = function(event: MouseEvent)
    {
        scaleX = 1.0;
        scaleY = 1.0;
    }

    override protected function create () : Node
    {
        Group
        {
            content:
            [
                Rectangle
                {
                        width: 140, height: 140
                        fill: Color.BLACK
                        effect: PerspectiveTransform
                        {
                                ulx: bind d.layoutX, uly: bind d.layoutY,       urx: bind c.centerX, ury: bind c.centerY

                                llx: bind a.layoutX, lly: bind a.layoutY,       lrx: bind b.layoutX, lry: bind b.layoutY
                        }
                }
                ,
                ImageView
                {
                    image: bind sideImage

                    effect: PerspectiveTransform
                    {
                            ulx: bind sideLeftX, uly: bind sideUpperLeftY,        urx: 15.0, ury: bind b.layoutY
                            llx: bind sideLeftX, lly: bind (sideUpperLeftY + 200.0),                 lrx: 15.0, lry: 210.0
                    }
                }                
                ,
                ImageView
                {
                    image: bind frontImage

                    effect: PerspectiveTransform
                    {
                        ulx: frontLeftX, uly: frontUpperLeftY,                      urx: bind frontRightX, ury: bind frontUpperRightY

                        llx: frontLeftX, lly: 210.0,                                lrx: bind frontRightX, lry: bind (frontUpperRightY + 180)
                    }
                }
                ,                
//                a, b, c, d
            ]
        }
    }
}
