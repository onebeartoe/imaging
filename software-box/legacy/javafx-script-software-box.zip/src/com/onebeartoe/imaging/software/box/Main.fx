
package com.onebeartoe.imaging.software.box;

import javax.swing.JFileChooser;

import javafx.stage.Stage;
import javafx.scene.Scene;

import javafx.scene.input.MouseEvent;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;

import buttons.nodes.GlimerButton;

var width = 675;

var height = 500;

var frontImageButton = GlimerButton
{
        text: "Front"

        layoutX: 415
        layoutY: 330

        scaleX: 0.4
        scaleY: 0.4
}

frontImageButton.onMouseReleased = function(event: MouseEvent)
{
        frontImageButton.scaleX = 0.4;
        frontImageButton.scaleY = 0.4;
}

var fileChooser = new JFileChooser();
var title = "Choose";

frontImageButton.onMouseClicked = function(event: MouseEvent)
{
    var result = fileChooser.showDialog(null, title);
    if ( result == JFileChooser.APPROVE_OPTION)
    {
        var infile = fileChooser.getSelectedFile();

        print ( infile.getName() );

        var image = Image
        {
                url: "file:///{infile.getAbsolutePath()}";
        }

        softwareBox.frontImage = image
    }
}

var sideImageButton = GlimerButton
{
        text: "Side"

        layoutX: -30
        layoutY: 330

        scaleX: 0.4
        scaleY: 0.4
}

sideImageButton.onMouseClicked = function(event: MouseEvent)
{
        var result = fileChooser.showDialog(null, title);
        if ( result == JFileChooser.APPROVE_OPTION)
        {
                var infile = fileChooser.getSelectedFile();

                print ( infile.getName() );

                var image = Image
                {
                        url: "file:///{infile.getAbsolutePath()}";
                }

                softwareBox.sideImage = image
        }
}

sideImageButton.onMouseReleased = function(event: MouseEvent)
{
        sideImageButton.scaleX = 0.4;
        sideImageButton.scaleY = 0.4;
}

var frontRightXSlider = Slider
{
	min: 186
	max: 220

        layoutX: 300
        layoutY: 350
}

var frontUpperLeftXSlider: Slider = Slider
{
        min: -20
        max: 20

        vertical: true

//        layoutX: bind  (stage.width / 2) - softwareBox.width
        layoutX: bind stage.width * 0.93;
//        layoutX: 500
        layoutY: 150
}

var sideLeftXSlider = Slider
{
	min: -15
	max: 15

        layoutX: 100
        layoutY: 350
}

var sideLeftYSlider = Slider
{
        min: -20
        max: 20

        layoutX: 25
        layoutY: 150

        vertical: true
}

var softwareBox : SoftwareBox = SoftwareBox
{
    layoutX: bind  (stage.width / 2) - softwareBox.width 

    layoutY: 100

    sideUpperLeftY: bind sideLeftYSlider.value
    frontRightX: bind frontRightXSlider.value
    frontUpperRightY: bind frontUpperLeftXSlider.value
    sideLeftX: bind sideLeftXSlider.value
}

softwareBox.onMouseClicked = function(event: MouseEvent)
{
        softwareBox.scaleX = 0.8;
        softwareBox.scaleY = 0.8;
        println("pressed")
}

softwareBox.requestFocus();

var stage: Stage = Stage
{
    title: "onebeartoe.net - Imaging - Software Box Generator"

    width: width
    height: height

    scene: Scene
    {
//        height: 500
        content:
        [
            softwareBox
            ,
            frontRightXSlider
            ,
            frontUpperLeftXSlider
            ,
            frontImageButton
            ,
            sideLeftXSlider
            ,
            sideLeftYSlider
            ,
            sideImageButton
        ]
    }
}

frontUpperLeftXSlider.layoutX = stage.width * 0.8;
